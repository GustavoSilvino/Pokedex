# Sprint 3 
Pull em 19/11

## Nota base do grupo: 17/20

## Requisitos obrigatórios
	✔️ completar o que não foi feito na sprint 2
	✔️ corrigir problemas detectados no código ou documentação
	✔️ ❌ cadastro validado e funcionando para vários usuários
	✔️ ❌ login validado e funcionando para vários usuários
		ambos acima chamando o submit e não finalizam
	✔️ pelo menos a primeira versão da página de perfil do usuário.

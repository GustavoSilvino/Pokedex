| Usuário      | Requisito | Motivação     |
| :----:        |    :----:   |          :----: |
| Como um cliente, eu quero      | acessar uma página<br>com informações gerais do produto       | para poder decidir se vou contratar o serviço.   |
| Como um usuário, eu quero   | ter acesso privado ao sistema        | para sentir confiança na privacidade<br>de meus dados e pedidos.      |



> Written with [StackEdit](https://stackedit.io/).

# Documentação do Projeto

A documentação do projeto é composta pelos seguintes itens: 
 - [Relatório Técnico](relatorio/Relatorio%20Tecnico%20-%20TEMPLATE.md)
 - [Backlog do projeto](backlog.md) ou link para Kanban utilizado.
 - [Vídeo de Demonstração](https://youtube.com)


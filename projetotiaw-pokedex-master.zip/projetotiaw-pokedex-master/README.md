![Open in Codespaces](https://classroom.github.com/assets/open-in-codespaces-abfff4d4e15f9e1bd8274d9a39a0befe03a0632bb0f153d0ec72ff541cedbe34.svg)
# Pokedex
Pokémon é uma franquia de jogos da Nintendo bastante famosa pelo mundo a fora.
Seu primeiro jogo foi lançado no dia 27 de fevereiro de 1996, e consistia em um jogo onde vc captura monstrinhos para batalhar
com outros treinadores e se tornar o melhor treinador.
Desde o primeiro jogo, a franquia vem aumentando seu leque de jogos e sua quantidade fãs, desde os mais novos aos mais velhos, e esses fãs
sempre tinham um grande problema em relação ao jogo: A Pokedéx.
A Pokédex sempre foi, nos jogos, um catalogo que apenas mostrava os Pokémon capturados daquela região em especifica, e nunca uma geral, além da pouca ou quase nada
filtragem de Pokémon presentes nos jogos, como o tipo e sua geração.
Nosso objetivo é resolver isso criando a nossa própria Pokedex, uma Pokédex geral com filtros a fim de corrigir os problemas da Pokedex original.

# Requisitos cumpridos: 100/100

# Nota de apresentação 90/100

**Importante:** A nota-base do grupo é calculada a partir das porcentagens acima. A nota individual leva em consideração ainda a nota de acompanhamento nas reuniões de grupos, a participação efetiva nas tarefas e commits e os descontos por falta nas reuniões. 

## Comentários da correção

Parabéns pelo trabalho, pessoal. Ficou completo, bem organizado, informações interessantes e totalmente funcional. A disposição de vocês com o projeto só com 2 pessoas foi admirável. 


## Alunos integrantes da equipe

* Diogo dos Santos Lopes
* Gustavo Ferreira
* Gustavo Silvino
* Julia Fernandes Malaquias

## Professores responsáveis

* Lucas Gabriel da Silva Felix
* João Caram Santos de Oliveira

## Quadro de tarefas
https://github.com/orgs/DisciplinasProgramacao/projects/38

## Instruções para uso
Criar conta: Acessar o site de cadastro -> colocar o nome -> colocar a senha -> responder a pergunta -> criar a conta -> acessar a pagina da pokedex.

Pokedex: na pagina principal: colocar o nome de algum Pokemon ou id -> apertar o botão para pesquisar -> esperar aparecer a informação na tela.

Opcional: na pagina principal: selecionar o tipo do Pokemon -> selecionar a geração do Pokemon -> apertar o botão para pesquisar -> apertar nas setas para ir trocando    o pokemon.
